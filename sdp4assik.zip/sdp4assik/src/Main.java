import java.util.ArrayList;
import java.util.List;

// Subject
interface AstronomyEventSubject {
    void registerObserver(Observer observer);
    void removeObserver(Observer observer);
    void notifyObservers(String event);
}

// Observer
interface Observer {
    void update(String event);
}

// Concrete Subject
class AstronomyEventMonitor implements AstronomyEventSubject {
    private List<Observer> observers = new ArrayList<>();

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(String event) {
        for (Observer observer : observers) {
            observer.update(event);
        }
    }

    // Simulate the detection of astronomy events
    public void detectEvent(String event) {
        System.out.println("Astronomy event detected: " + event);
        notifyObservers(event);
    }
}

// Concrete Observers
class SupernovaObserver implements Observer {
    @Override
    public void update(String event) {
        if ("Supernova spotted".equals(event)) {
            System.out.println("Supernova alert: A supernova has been spotted!");
        }
    }
}

class CometObserver implements Observer {
    @Override
    public void update(String event) {
        if ("Comet sighting".equals(event)) {
            System.out.println("Comet alert: A comet has been sighted!");
        }
    }
}

class AlienObserver implements Observer {
    @Override
    public void update(String event) {
        if ("Alien invasion".equals(event)) {
            System.out.println("Alien alert: We're being invaded by aliens!");
        }
    }
}



class AstronomyEventApp {
    public static void main(String[] args) {
        AstronomyEventMonitor astronomyEventMonitor = new AstronomyEventMonitor();

        SupernovaObserver supernovaObserver = new SupernovaObserver();
        CometObserver cometObserver = new CometObserver();
        AlienObserver alienObserver = new AlienObserver();

        astronomyEventMonitor.registerObserver(supernovaObserver);
        astronomyEventMonitor.registerObserver(cometObserver);
        astronomyEventMonitor.registerObserver(alienObserver);

        // Simulate astronomy events
        astronomyEventMonitor.detectEvent("Supernova spotted");
        astronomyEventMonitor.detectEvent("Comet sighting");
        astronomyEventMonitor.detectEvent("Alien invasion");
    }
}
